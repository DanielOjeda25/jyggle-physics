JIGGLE_PRESETS = {
    'BREASTS': {'stiff': 0.15, 'damp': 0.72, 'icon': 'HEART', 'keys': ['breast', 'pecho', 'boob']},
    'BUTT':    {'stiff': 0.35, 'damp': 0.82, 'icon': 'MOD_CLOTH', 'keys': ['butt', 'culo', 'rear', '尻']},
}
